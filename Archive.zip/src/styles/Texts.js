const texts = {
  textTerms: '@assets/texts/terms.html',
};

export default texts;
