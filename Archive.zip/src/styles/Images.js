const images = {
  imgBannerDummy: require('@assets/dummys/dummyBanner.png'),
  imgMapDummy: require('@assets/dummys/mapdummy.png'),
  imgLogoWhite: require('@assets/logos/logo_kolula_white.png'),
  imgLogoColor: require('@assets/logos/logo_kolula_color.png'),

  imgRule1: require('@assets/rules/rules01.png'),
  imgRule2: require('@assets/rules/rules02.png'),
  imgRule3: require('@assets/rules/rules03.png'),
  imgRule4: require('@assets/rules/rules04.png'),
};

export default images;
