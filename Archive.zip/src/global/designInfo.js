export const DESIGN_WIDTH =  1242;
export const DESIGN_HEIGHT = 2208;