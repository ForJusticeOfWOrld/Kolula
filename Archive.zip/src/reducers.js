import auth from './pages/login/reducer';
//import tests from './tests/reducer';
//import book from './pages/book/reducer';
//import bike from './pages/bike/reducer';
import multiLang from './multi_lang/reducer';

export {
    auth,
    multiLang,
};